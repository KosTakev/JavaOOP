package catHouse.core;

public interface Engine extends Runnable {
}

