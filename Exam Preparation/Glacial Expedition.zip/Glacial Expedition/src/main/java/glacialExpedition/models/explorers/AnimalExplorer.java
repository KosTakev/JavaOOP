package glacialExpedition.models.explorers;

public class AnimalExplorer extends BaseExplorer{
    public AnimalExplorer(String name) {
        super(name, 100);
    }
}
