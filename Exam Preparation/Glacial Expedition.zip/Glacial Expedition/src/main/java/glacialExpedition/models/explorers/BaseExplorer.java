package glacialExpedition.models.explorers;

import glacialExpedition.models.suitcases.Suitcase;

public abstract class BaseExplorer implements Explorer {
    private String name;
    private double energy;
    private Suitcase suitcase;

    protected BaseExplorer(String name, double energy) {
        //TODO setters and validations
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public double getEnergy() {
        return this.energy;
    }

    @Override
    public boolean canSearch() {
        return false;
    }

    @Override
    public Suitcase getSuitcase() {
        return this. suitcase;
    }

    @Override
    public void search() {

    }
}
